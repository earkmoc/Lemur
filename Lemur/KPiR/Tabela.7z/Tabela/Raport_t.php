
<table border="1" cellpadding="3" cellspacing="0" width="100%" style="font-family: arial;">
<tr align="center" style="font-size: 10px;">
<td rowspan="2">LP</td>
<td rowspan="2" width="5%">Data zdarzenia gospodarczego</td>
<td rowspan="2" width="5%">Nr dowodu ksi�gowego</td>
<td rowspan="1" colspan="2">Kontrahent</td>
<td rowspan="2">Opis zdarzenia gospodarczego</td>
<td rowspan="1" colspan="3">Przych�d</td>
</tr>
<tr align="center" style="font-size: 10px;">
<td rowspan="1">imi� i nazwisko (firma)</td>
<td rowspan="1">adres</td>
<td rowspan="1" width="5%">warto�� sprzedanych towar�w i us�ug</td>
<td rowspan="1" width="5%">pozosta�e przychody</td>
<td rowspan="1" width="5%">razem przych�d (7+8)</td>
</tr>
<tr style="font-size: 8px;" >
<td style="font-size: 8px; padding: 1px;" > </td>
<td style="font-size: 8px; padding: 1px;" > </td>
<td style="font-size: 8px; padding: 1px;" > </td>
<td style="font-size: 8px; padding: 1px;" > </td>
<td style="font-size: 8px; padding: 1px;" > </td>
<td style="font-size: 8px; padding: 1px;" > </td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
</tr>
<tr align="center">
<td style="font-size: 8px; padding: 1px;" >1</td>
<td style="font-size: 8px; padding: 1px;" >2</td>
<td style="font-size: 8px; padding: 1px;" >3</td>
<td style="font-size: 8px; padding: 1px;" >4</td>
<td style="font-size: 8px; padding: 1px;" >5</td>
<td style="font-size: 8px; padding: 1px;" >6</td>
<td style="font-size: 8px; padding: 1px;" >7</td>
<td style="font-size: 8px; padding: 1px;" >8</td>
<td style="font-size: 8px; padding: 1px;" >9</td>
</tr>
