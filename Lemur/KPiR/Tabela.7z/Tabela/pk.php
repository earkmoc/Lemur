<?php

require("setup.php");
require("{$_SERVER['DOCUMENT_ROOT']}/Lemur2/saveTablePosition.php");
require("{$_SERVER['DOCUMENT_ROOT']}/Lemur2/WydrukWzor.php");
