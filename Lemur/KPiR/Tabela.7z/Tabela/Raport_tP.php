
<table border="1" cellpadding="3" cellspacing="0" width="100%" style="font-family: arial;">
<tr align="center" style="font-size: 10px;">
<td rowspan="2" width="1%">LP</td>
<td rowspan="2" width="5%">Zakup towar�w handlowych i materia��w wg cen zakupu</td>
<td rowspan="2" width="5%">Koszty uboczne zakupu</td>
<td rowspan="1" width="5%" colspan="4">Wydatki (koszty)</td>
<td rowspan="1" width="5%" colspan="2">Koszty dzia�alno�ci badawczo-rozwojowej, o kt�rych mowa w art. 26e ustawy o podatku dochodowym</td>
<td rowspan="2" width="5%">Uwagi</td>
</tr>
<tr align="center" style="font-size: 10px;">
<td rowspan="1" width="5%">wynagrodzenia w got�wce i w naturze</td>
<td rowspan="1" width="5%">pozosta�e wydatki</td>
<td rowspan="1" width="5%">razem wydatki (12+13)</td>
<td rowspan="1" width="5%"> </td>
<td rowspan="1" width="5%">opis kosztu</td>
<td rowspan="1" width="5%">warto��</td>
</tr>
<tr style="font-size: 8px;" >
<td style="font-size: 8px; padding: 1px;" > </td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
<td style="font-size: 8px; padding: 1px;" > </td>
<td style="font-size: 8px; padding: 1px;" align="right">z�, gr</td>
<td style="font-size: 8px; padding: 1px;" > </td>
</tr>
<tr align="center">
<td style="font-size: 8px; padding: 1px;" > </td>
<td style="font-size: 8px; padding: 1px;" >10</td>
<td style="font-size: 8px; padding: 1px;" >11</td>
<td style="font-size: 8px; padding: 1px;" >12</td>
<td style="font-size: 8px; padding: 1px;" >13</td>
<td style="font-size: 8px; padding: 1px;" >14</td>
<td style="font-size: 8px; padding: 1px;" >15</td>
<td style="font-size: 8px; padding: 1px;" colspan='2'>16</td>
<td style="font-size: 8px; padding: 1px;" >17</td>
</tr>
