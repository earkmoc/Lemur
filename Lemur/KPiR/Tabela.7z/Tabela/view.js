$(document).ready(function() {
	$('input[name=okres]').focus();
	$('input[name=tytul]').focus();
});
