<?php

require("{$_SERVER['DOCUMENT_ROOT']}/Lemur2/szukaj.php");
