<table border="0" width="100%" style="font-family: arial;">
<tr>
<td>
Miesi�cami rok: <?php echo $_POST['rok'];?>
</td>
<td align="right">
strona: <?php echo $strona;?>
</td>
</tr>
</table>
