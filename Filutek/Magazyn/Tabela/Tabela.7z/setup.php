<?php

require("{$_SERVER['DOCUMENT_ROOT']}/Lemur2/dbconnect.php");

// ----------------------------------------------
// Parametry widoku

$title='Magazyn';
$tabela='towary';
$widok=$tabela;
$mandatory='1';
require("{$_SERVER['DOCUMENT_ROOT']}/Lemur2/tableFields.php");

//----------------------------------------------

$params="idTabeli=$idTabeli&row='+row+'&col='+col+'&str='+str+'&id=";
$esc="saveTablePosition.php?next=http://{$_SERVER['HTTP_HOST']}/$baza/Menu/&$params'+GetID()+'";
$formularz="../Formularz/?$params'+GetID()+'";
$dopisz="../Formularz/?{$params}0'+'";
$kopia="../Formularz/?$params-'+GetID()+'";
$usun="usun.php?$params'+GetID()+'";

$buttons=array();

if	( (isset($_SESSION["{$baza}DokumentyID_D"]))
	||(isset($_SESSION["{$baza}KprID_D"]))
	||(isset($_SESSION["{$baza}SrodkiTrID_D"]))
	)
{
	$buttons[]=array('klawisz'=>'AltM','nazwa'=>'M=wyj�cie','js'=>"parent.$('#myModal').modal('hide');parent.$('input[name=NAZWA]').focus();");
	$buttons[]=array('klawisz'=>'Enter','nazwa'=>'Enter=wyb�r','js'=>"
		parent.$('#myModal').modal('hide');
		parent.$('select[name=TYP]').val(parent.$('select[name=TYP] option:contains(\"'+$('tr[data-index='+(row-1)+']>td:nth-child(5)').text()+' -\")').text());
		parent.$('input[name=NAZWA]').val($('tr[data-index='+(row-1)+']>td:nth-child(2)').text());
		parent.$('input[name=INDEKS]').val($('tr[data-index='+(row-1)+']>td:nth-child(3)').text());
		parent.$('input[name=PKWIU]').val($('tr[data-index='+(row-1)+']>td:nth-child(4)').text());
		parent.$('input[name=JM]').val($('tr[data-index='+(row-1)+']>td:nth-child(10)').text());
		parent.$('select[name=STAWKA]').val(parent.$('select[name=STAWKA] option:contains(\"'+$('tr[data-index='+(row-1)+']>td:nth-child(11)').text()+' -\")').text());
		parent.$('input[name=CENABEZR]').val($('tr[data-index='+(row-1)+']>td:nth-child(8)').text());
		parent.$('input[name=RABAT]').val('');
		parent.$('input[name=CENA]').val('');
		parent.$('input[name=NETTO]').val('');
		parent.$('input[name=VAT]').val('');
		parent.$('input[name=BRUTTO]').val('');
		parent.$('input[name=ILOSC]').val($('tr[data-index='+(row-1)+']>td:nth-child(9)').text());
		parent.$('input[name=ILOSC]').focus();
		parent.$('input[name=ILOSC]').select();
	");
	$buttons[]=array('klawisz'=>'AltF','nazwa'=>'Formularz','akcja'=>$formularz);
} else
{
	$buttons[]=array('klawisz'=>'Esc','nazwa'=>'Esc=wyj�cie','akcja'=>$esc);
	$buttons[]=array('klawisz'=>'Enter','nazwa'=>'','akcja'=>$formularz);
	$buttons[]=array('klawisz'=>'AltF','nazwa'=>'Enter=Formularz','akcja'=>$formularz);
	$buttons[]=array('klawisz'=>'AltW','nazwa'=>'Wydruk','akcja'=>"Wydruk.php?wydruk=Raporta&natab=$tabela&strona1=15&stronan=20");
}
$buttons[]=array('klawisz'=>'AltD','nazwa'=>'Dopisz','akcja'=>$dopisz);
$buttons[]=array('klawisz'=>'AltC','nazwa'=>'Copy','akcja'=>$kopia);
$buttons[]=array('klawisz'=>'AltU','nazwa'=>'Usu�','akcja'=>$usun);
$buttons[]=array('klawisz'=>'AltS','nazwa'=>'Szukaj','js'=>"$('#modalSzukaj').modal('show')");
$buttons[]=array('klawisz'=>'AltA','nazwa'=>'Aktywne','akcja'=>"aktywne.php?$params'+GetID()+'");

require("{$_SERVER['DOCUMENT_ROOT']}/Lemur2/navigationButtons.php");
